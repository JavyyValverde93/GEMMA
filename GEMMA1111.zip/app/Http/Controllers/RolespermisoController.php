<?php

namespace App\Http\Controllers;

use App\Models\Rolespermiso;
use Illuminate\Http\Request;

class RolespermisoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Rolespermiso  $rolespermiso
     * @return \Illuminate\Http\Response
     */
    public function show(Rolespermiso $rolespermiso)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Rolespermiso  $rolespermiso
     * @return \Illuminate\Http\Response
     */
    public function edit(Rolespermiso $rolespermiso)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Rolespermiso  $rolespermiso
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Rolespermiso $rolespermiso)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Rolespermiso  $rolespermiso
     * @return \Illuminate\Http\Response
     */
    public function destroy(Rolespermiso $rolespermiso)
    {
        //
    }
}
