<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tutor extends Model
{
    use HasFactory;

    protected $fillable = ['nombre_tutor1', 'relacion_tutor1', 'vive_con', 'nombre_tutor2', 'relacion_tutor2', 'estado_civil'];

    public function User(){
        return $this->belongsTo(User::class);
    }
}
