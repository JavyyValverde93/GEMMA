<?php

namespace Database\Factories;

use App\Models\Facturacion;
use Illuminate\Database\Eloquent\Factories\Factory;

class FacturacionFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Facturacion::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
